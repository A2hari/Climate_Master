Climate_Master

This is a Weather app that Fetches the The weather report of a particular area based on area name or the zip code you give. This application wishes you morning,afternoon,evening,night as the time moves on.The following fields you get for a particular area weather report

    Area Name
    Latitude
    Longitude
    Climatic condition
    Humidity in air
    Temperature in the specific/requested Area
    Wind Speed
    Wind Direction
    Sunrise Time
    Sunset Time

Terms and Conditions

    This is a app built on the Free API Key so as No hits more than 60 overall(Global Usage Limit) from this app
    So If you want to use this app for your personal usage we strongly recommend you to get a API key form the open weather sign up there you will get a free key if you want you can even upgrade your api key there and replace your API key with my API key
    We don't collect your personal data or no information collection code is written in the back end
    The app is not allowed to publish in the windows store or any other stores directly or by any other means. One can use our app for free of cost from here
    Read Usage to know the usage process

Usage

    In order to use this file install The following packages
    i) DateTime
    ii) requests
    iii) tkintler
    iv) time
    v) messagebox
    Make sure that both cloud.ico and the mountains.png are in both a single folder
    Boom The app is ready to use
