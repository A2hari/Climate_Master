# Climate_Master

This is a Weather app that Fetches the The weather report of a particular area based on area name or the zip code you give. This application wishes you morning,afternoon,evening,night as the time moves on.The following fields you get for a particular area weather report

1.  Area Name
2.  Latitude
3.  Longitude
4.  Climatic condition
5.  Humidity in air
6.  Temperature in the specific/requested Area
7.  Wind Speed
8.  Wind Direction
9.  Sunrise Time 
10. Sunset Time

# Terms and Conditions 

1) This is a app built on the Free API Key so as No hits more than 60 overall(Global Usage Limit) from this app 
2) So If you want to use this app for your personal usage we strongly recommend you to get a API key form the [open weather]( https://home.openweathermap.org/users/sign_up) sign up there you will get a free key if you want you can even upgrade your api key there and replace your API key with my API key
3) We don't collect your personal data or no information collection code is written in the back end 
4) The app is not allowed to publish in the windows store or any other stores directly or by any other means. One can use our app for free of cost from here
5) Read Usage to know the usage process

# Usage
1) In order to use this file install The following packages <br/>
   i)   DateTime   <br/>
   ii)  requests   <br/>
   iii) tkintler   <br/>
   iv)  time       <br/>
   v)   messagebox <br/>
2) Make sure that both cloud.ico and the mountains.png are in both a single folder
3) **Boom** The app is ready to use 
 
